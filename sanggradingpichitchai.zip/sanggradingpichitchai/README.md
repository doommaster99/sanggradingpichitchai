# สั่นกระดิ่งพิชิตชัย

เกมตอบคำถามสำหรับห้องเรียน (เล่นคนเดียว / แข่งกดกระดิ่ง) ใช้ได้ทุกวิชา นำเข้าคำถามจาก Google Sheet หรือ Excel/CSV

## โครงสร้าง
- `index.html` + `img/` : เวอร์ชันเว็บทั่วไป เปิดผ่าน GitHub Pages ได้ทันที
- `apps-script/Code.gs`, `apps-script/Index.html` : เวอร์ชันเชื่อม Google Apps Script (โหลดชุดคำถามจากชีต / บันทึกผลลงแท็บ "ผลคะแนน")

## เปิดใช้งานผ่าน GitHub Pages
Settings → Pages → Source: Deploy from a branch → Branch: main, โฟลเดอร์ / (root) → Save
แล้วเปิดที่ https://ชื่อบัญชี.github.io/ชื่อrepo/
